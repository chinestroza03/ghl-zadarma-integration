const crypto = require('crypto');
const axios = require('axios');
const CallLog = require('../models/CallLog');

// Configuración de la API de Zadarma
const ZADARMA_KEY = process.env.ZADARMA_KEY;
const ZADARMA_SECRET = process.env.ZADARMA_SECRET;
const ZADARMA_API_URL = 'https://api.zadarma.com/v1';

// Función para generar la firma para la API de Zadarma
const generateZadarmaSignature = (method, url, params = {}) => {
  const sortedParams = Object.keys(params)
    .sort()
    .reduce((result, key) => {
      result[key] = params[key];
      return result;
    }, {});

  const paramsString = Object.entries(sortedParams)
    .map(([key, value]) => `${key}=${value}`)
    .join('&');

  const data = method + url + paramsString + ZADARMA_SECRET;
  return crypto.createHash('md5').update(data).digest('hex');
};

// @desc    Iniciar una llamada con Zadarma
// @route   POST /api/calls/initiate
exports.initiateCall = async (req, res) => {
  try {
    const { phoneNumber, callerId } = req.body;
    
    if (!phoneNumber) {
      return res.status(400).json({ msg: 'El número de teléfono es requerido' });
    }
    
    // Parámetros para la solicitud a Zadarma
    const params = {
      from: callerId || process.env.DEFAULT_CALLER_ID,
      to: phoneNumber,
      sip: process.env.ZADARMA_SIP_ID || ''
    };
    
    // URL para la API de Zadarma
    const url = '/request/callback/';
    
    // Generar firma
    const signature = generateZadarmaSignature('POST', url, params);
    
    // Headers para Zadarma
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `${ZADARMA_KEY}:${signature}`
    };
    
    // Hacer solicitud a Zadarma
    const response = await axios.post(`${ZADARMA_API_URL}${url}`, params, { headers });
    
    res.json(response.data);
  } catch (error) {
    console.error('Error al iniciar llamada con Zadarma:', error.message);
    res.status(500).send('Error del servidor al iniciar la llamada');
  }
};

// @desc    Obtener estado de una llamada con Zadarma
// @route   GET /api/calls/:id/status
exports.getCallStatus = async (req, res) => {
  try {
    const { id } = req.params;
    
    // URL para la API de Zadarma
    const url = `/statistics/pbx/call/${id}/`;
    
    // Generar firma
    const signature = generateZadarmaSignature('GET', url);
    
    // Headers para Zadarma
    const headers = {
      'Authorization': `${ZADARMA_KEY}:${signature}`
    };
    
    // Hacer solicitud a Zadarma
    const response = await axios.get(`${ZADARMA_API_URL}${url}`, { headers });
    
    res.json(response.data);
  } catch (error) {
    console.error(`Error al obtener estado de llamada ${req.params.id}:`, error.message);
    
    if (error.response && error.response.status === 404) {
      return res.status(404).json({ msg: 'Llamada no encontrada' });
    }
    
    res.status(500).send('Error del servidor al obtener el estado de la llamada');
  }
};

// @desc    Registrar una llamada en el sistema
// @route   POST /api/calls/log
exports.logCall = async (req, res) => {
  try {
    const { callId, type, callerId, destination, userId, startTime, duration, disposition } = req.body;
    
    // Crear nuevo registro de llamada
    const callLog = new CallLog({
      callId: callId || crypto.randomUUID(),
      type,
      callerId,
      destination,
      userId,
      startTime: startTime || new Date(),
      duration,
      disposition,
    });
    
    await callLog.save();
    
    res.json(callLog);
  } catch (error) {
    console.error('Error al registrar llamada:', error.message);
    res.status(500).send('Error del servidor al registrar la llamada');
  }
};

// @desc    Obtener historial de llamadas
// @route   GET /api/calls/history
exports.getCallHistory = async (req, res) => {
  try {
    const { userId, startDate, endDate, type, limit = 50, page = 1 } = req.query;
    
    // Construir filtro
    const filter = {};
    
    if (userId) {
      filter.userId = userId;
    }
    
    if (startDate && endDate) {
      filter.startTime = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    } else if (startDate) {
      filter.startTime = { $gte: new Date(startDate) };
    } else if (endDate) {
      filter.startTime = { $lte: new Date(endDate) };
    }
    
    if (type && type !== 'all') {
      filter.type = type;
    }
    
    // Calcular skip para paginación
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Obtener llamadas
    const calls = await CallLog.find(filter)
      .sort({ startTime: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    
    // Contar total de llamadas para la paginación
    const total = await CallLog.countDocuments(filter);
    
    res.json({
      data: calls,
      meta: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('Error al obtener historial de llamadas:', error.message);
    res.status(500).send('Error del servidor al obtener el historial de llamadas');
  }
};

// @desc    Obtener configuración SIP para WebPhone
// @route   GET /api/calls/sip-config
exports.getSipConfiguration = async (req, res) => {
  try {
    // Obtener configuración de variables de entorno
    const sipConfig = {
      sipId: process.env.ZADARMA_SIP_ID,
      sipPassword: process.env.ZADARMA_SIP_PASSWORD,
      sipDomain: process.env.ZADARMA_SIP_DOMAIN,
      webSocketUrl: process.env.ZADARMA_WEBSOCKET_URL
    };
    
    // Asegurarse de que todos los valores estén presentes
    const missingValues = Object.entries(sipConfig)
      .filter(([_, value]) => !value)
      .map(([key]) => key);
    
    if (missingValues.length > 0) {
      return res.status(500).json({
        success: false,
        error: `Configuración SIP incompleta. Falta: ${missingValues.join(', ')}`
      });
    }
    
    res.json({
      success: true,
      data: sipConfig
    });
  } catch (error) {
    console.error('Error al obtener configuración SIP:', error);
    res.status(500).json({
      success: false,
      error: 'Error al obtener configuración SIP'
    });
  }
};