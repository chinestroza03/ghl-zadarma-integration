const axios = require('axios');

// Configuración de la API de GHL
const GHL_API_KEY = process.env.GHL_API_KEY;
const GHL_API_URL = 'https://rest.gohighlevel.com/v1';

// Headers para las solicitudes a GHL
const ghlHeaders = {
  'Authorization': `Bearer ${GHL_API_KEY}`,
  'Content-Type': 'application/json'
};

// @desc    Obtener todos los usuarios/contactos de GHL
// @route   GET /api/users
exports.getUsers = async (req, res) => {
  try {
    // Obtener parámetros de consulta para filtrado y paginación
    const { limit = 100, page = 1, query = '', status } = req.query;
    
    // Construir URL con parámetros
    let url = `${GHL_API_URL}/contacts?limit=${limit}&page=${page}`;
    
    if (query) {
      url += `&query=${query}`;
    }
    
    if (status) {
      url += `&status=${status}`;
    }
    
    // Hacer solicitud a GHL
    const response = await axios.get(url, { headers: ghlHeaders });
    
    res.json(response.data);
  } catch (error) {
    console.error('Error al obtener usuarios de GHL:', error.message);
    res.status(500).send('Error del servidor al obtener usuarios');
  }
};

// @desc    Obtener un usuario/contacto específico de GHL
// @route   GET /api/users/:id
exports.getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Hacer solicitud a GHL
    const response = await axios.get(`${GHL_API_URL}/contacts/${id}`, { 
      headers: ghlHeaders 
    });
    
    res.json(response.data);
  } catch (error) {
    console.error(`Error al obtener usuario ${req.params.id} de GHL:`, error.message);
    
    if (error.response && error.response.status === 404) {
      return res.status(404).json({ msg: 'Usuario no encontrado' });
    }
    
    res.status(500).send('Error del servidor al obtener el usuario');
  }
};

// @desc    Buscar usuarios por término de búsqueda
// @route   GET /api/users/search
exports.searchUsers = async (req, res) => {
  try {
    const { query } = req.query;
    
    if (!query) {
      return res.status(400).json({ msg: 'Se requiere un término de búsqueda' });
    }
    
    // Construir URL con parámetros
    const url = `${GHL_API_URL}/contacts?query=${query}`;
    
    // Hacer solicitud a GHL
    const response = await axios.get(url, { headers: ghlHeaders });
    
    res.json(response.data);
  } catch (error) {
    console.error('Error al buscar usuarios:', error.message);
    res.status(500).send('Error del servidor al buscar usuarios');
  }
};

// @desc    Agregar una nota a un contacto en GHL
// @route   POST /api/users/:id/notes
exports.addNoteToUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { body } = req.body;
    
    if (!body) {
      return res.status(400).json({ msg: 'El contenido de la nota es requerido' });
    }
    
    // Crear la nota
    const noteData = {
      body
    };
    
    // Hacer solicitud a GHL
    const response = await axios.post(`${GHL_API_URL}/contacts/${id}/notes`, noteData, {
      headers: ghlHeaders
    });
    
    res.json(response.data);
  } catch (error) {
    console.error(`Error al agregar nota al usuario ${req.params.id}:`, error.message);
    res.status(500).send('Error del servidor al agregar la nota');
  }
};