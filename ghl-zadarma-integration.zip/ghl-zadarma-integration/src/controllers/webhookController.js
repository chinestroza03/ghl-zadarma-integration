const crypto = require('crypto');
const axios = require('axios');
const User = require('../models/User');
const CallLog = require('../models/CallLog');

// Configuración de la API de Zadarma
const ZADARMA_SECRET = process.env.ZADARMA_SECRET;

// Función para verificar la firma de Zadarma
const verifyZadarmaSignature = (data, signature) => {
  if (!ZADARMA_SECRET) {
    console.error('Zadarma secret no está configurado');
    return false;
  }

  const calculatedSignature = crypto
    .createHash('sha1')
    .update(JSON.stringify(data) + ZADARMA_SECRET)
    .digest('hex');

  return calculatedSignature === signature;
};

/**
 * @desc    Webhook para notificaciones de Zadarma
 * @route   POST /api/webhook/zadarma
 * @access  Public
 */
exports.zadarmaWebhook = async (req, res) => {
  try {
    // Obtener la firma del header
    const signature = req.header('signature');
    
    if (!signature) {
      return res.status(400).json({ error: 'Falta la firma' });
    }
    
    // Verificar la firma
    if (!verifyZadarmaSignature(req.body, signature)) {
      return res.status(401).json({ error: 'Firma inválida' });
    }
    
    // Procesar el evento según su tipo
    const { event, call_id, caller_id, destination, disposition, duration } = req.body;
    
    switch (event) {
      case 'NOTIFY_START':
        // Una llamada ha comenzado
        await handleCallStart(call_id, caller_id, destination);
        break;
        
      case 'NOTIFY_END':
        // Una llamada ha terminado
        await handleCallEnd(call_id, disposition, duration);
        break;
        
      case 'NOTIFY_OUT_START':
        // Una llamada saliente ha comenzado
        await handleOutgoingCallStart(call_id, caller_id, destination);
        break;
        
      case 'NOTIFY_OUT_END':
        // Una llamada saliente ha terminado
        await handleOutgoingCallEnd(call_id, disposition, duration);
        break;
        
      case 'NOTIFY_ANSWER':
        // Una llamada ha sido contestada
        await handleCallAnswer(call_id);
        break;
        
      default:
        console.log(`Evento de Zadarma no manejado: ${event}`);
    }
    
    // Responder con éxito
    res.status(200).json({ status: 'OK' });
  } catch (error) {
    console.error('Error en el webhook de Zadarma:', error.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

/**
 * Maneja el inicio de una llamada entrante
 */
const handleCallStart = async (callId, callerId, destination) => {
  try {
    // Buscar el usuario asociado con el número de teléfono del destinatario
    const user = await findUserByPhone(destination);
    
    // Crear un nuevo registro de llamada
    const callLog = new CallLog({
      callId,
      type: 'incoming',
      status: 'ringing',
      callerId,
      destination,
      userId: user ? user.id : null,
      startTime: new Date()
    });
    
    await callLog.save();
    
    // Si hay un usuario, actualizar su historial de interacciones en GHL
    if (user) {
      await updateGHLInteraction(user.id, 'call_incoming', {
        callId,
        phone: callerId
      });
    }
    
  } catch (error) {
    console.error(`Error al manejar inicio de llamada ${callId}:`, error);
  }
};

/**
 * Maneja el fin de una llamada
 */
const handleCallEnd = async (callId, disposition, duration) => {
  try {
    // Buscar el registro de la llamada
    const callLog = await CallLog.findOne({ callId });
    
    if (!callLog) {
      console.error(`No se encontró registro para la llamada ${callId}`);
      return;
    }
    
    // Actualizar el registro
    callLog.status = 'completed';
    callLog.disposition = disposition;
    callLog.duration = duration;
    callLog.endTime = new Date();
    
    await callLog.save();
    
    // Si hay un usuario, actualizar su historial de interacciones en GHL
    if (callLog.userId) {
      await updateGHLInteraction(callLog.userId, 'call_completed', {
        callId,
        duration,
        disposition
      });
    }
    
  } catch (error) {
    console.error(`Error al manejar fin de llamada ${callId}:`, error);
  }
};

/**
 * Maneja el inicio de una llamada saliente
 */
const handleOutgoingCallStart = async (callId, callerId, destination) => {
  try {
    // Buscar el usuario asociado con el número de teléfono del destinatario
    const user = await findUserByPhone(destination);
    
    // Crear un nuevo registro de llamada
    const callLog = new CallLog({
      callId,
      type: 'outgoing',
      status: 'calling',
      callerId,
      destination,
      userId: user ? user.id : null,
      startTime: new Date()
    });
    
    await callLog.save();
    
    // Si hay un usuario, actualizar su historial de interacciones en GHL
    if (user) {
      await updateGHLInteraction(user.id, 'call_outgoing', {
        callId,
        phone: destination
      });
    }
    
  } catch (error) {
    console.error(`Error al manejar inicio de llamada saliente ${callId}:`, error);
  }
};

/**
 * Maneja el fin de una llamada saliente
 */
const handleOutgoingCallEnd = async (callId, disposition, duration) => {
  try {
    // El manejo es similar a handleCallEnd
    await handleCallEnd(callId, disposition, duration);
  } catch (error) {
    console.error(`Error al manejar fin de llamada saliente ${callId}:`, error);
  }
};

/**
 * Maneja cuando una llamada es contestada
 */
const handleCallAnswer = async (callId) => {
  try {
    // Buscar el registro de la llamada
    const callLog = await CallLog.findOne({ callId });
    
    if (!callLog) {
      console.error(`No se encontró registro para la llamada ${callId}`);
      return;
    }
    
    // Actualizar el registro
    callLog.status = 'active';
    callLog.answerTime = new Date();
    
    await callLog.save();
    
  } catch (error) {
    console.error(`Error al manejar respuesta de llamada ${callId}:`, error);
  }
};

/**
 * Busca un usuario por número de teléfono
 */
const findUserByPhone = async (phoneNumber) => {
  try {
    return await User.findOne({ phone: phoneNumber });
  } catch (error) {
    console.error(`Error al buscar usuario por teléfono ${phoneNumber}:`, error);
    return null;
  }
};

/**
 * Actualiza la interacción en GHL
 */
const updateGHLInteraction = async (userId, type, data) => {
  try {
    // Configuración para la API de GHL
    const GHL_API_KEY = process.env.GHL_API_KEY;
    const GHL_API_URL = 'https://rest.gohighlevel.com/v1';
    
    // Headers para las solicitudes a GHL
    const headers = {
      'Authorization': `Bearer ${GHL_API_KEY}`,
      'Content-Type': 'application/json'
    };
    
    // Obtener el contacto de GHL
    const user = await User.findById(userId);
    
    if (!user || !user.ghlContactId) {
      console.error(`No se encontró ID de contacto GHL para el usuario ${userId}`);
      return;
    }
    
    // Crear la nota o interacción en GHL
    const interactionData = {
      contactId: user.ghlContactId,
      type: 'note',
      body: createInteractionMessage(type, data)
    };
    
    // Enviar a GHL
    await axios.post(`${GHL_API_URL}/contacts/${user.ghlContactId}/notes`, 
      interactionData, 
      { headers }
    );
    
  } catch (error) {
    console.error(`Error al actualizar interacción en GHL para usuario ${userId}:`, error);
  }
};

/**
 * Crea un mensaje para la interacción según el tipo
 */
const createInteractionMessage = (type, data) => {
  switch (type) {
    case 'call_incoming':
      return `Llamada entrante desde ${data.phone}. ID: ${data.callId}`;
      
    case 'call_outgoing':
      return `Llamada saliente a ${data.phone}. ID: ${data.callId}`;
      
    case 'call_completed':
      const status = data.disposition === 'answered' ? 'contestada' : 'no contestada';
      const duration = data.duration ? `Duración: ${formatDuration(data.duration)}` : '';
      return `Llamada ${status}. ${duration} ID: ${data.callId}`;
      
    default:
      return `Interacción de llamada: ${type}`;
  }
};

/**
 * Formatea la duración en segundos a formato MM:SS
 */
const formatDuration = (seconds) => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
};