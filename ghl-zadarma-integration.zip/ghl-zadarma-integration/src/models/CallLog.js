const mongoose = require('mongoose');

const CallLogSchema = new mongoose.Schema({
  callId: {
    type: String,
    required: true,
    unique: true
  },
  type: {
    type: String,
    enum: ['incoming', 'outgoing'],
    required: true
  },
  status: {
    type: String,
    enum: ['ringing', 'calling', 'active', 'completed', 'missed', 'failed'],
    default: 'ringing'
  },
  callerId: {
    type: String,
    required: true
  },
  destination: {
    type: String,
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  startTime: {
    type: Date,
    required: true
  },
  answerTime: {
    type: Date,
    default: null
  },
  endTime: {
    type: Date,
    default: null
  },
  duration: {
    type: Number,
    default: 0
  },
  disposition: {
    type: String,
    enum: ['answered', 'busy', 'noanswer', 'failed', 'canceled'],
    default: null
  },
  recording: {
    type: String,
    default: null
  },
  notes: {
    type: String,
    default: null
  }
}, { timestamps: true });

module.exports = mongoose.model('CallLog', CallLogSchema);