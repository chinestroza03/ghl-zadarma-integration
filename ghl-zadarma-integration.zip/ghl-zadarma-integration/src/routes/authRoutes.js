const express = require('express');
const router = express.Router();
const { login, getUser, register } = require('../controllers/authController');
const auth = require('../middleware/auth');

// @route   POST api/auth/login
// @desc    Autenticar usuario y obtener token
// @access  Public
router.post('/login', login);

// @route   GET api/auth/user
// @desc    Obtener información del usuario actual
// @access  Private
router.get('/user', auth, getUser);

// @route   POST api/auth/register
// @desc    Registrar un nuevo usuario
// @access  Admin
router.post('/register', register);

module.exports = router;