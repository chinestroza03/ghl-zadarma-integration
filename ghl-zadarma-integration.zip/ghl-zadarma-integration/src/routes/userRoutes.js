const express = require('express');
const router = express.Router();
const { getUsers, getUserById, searchUsers, addNoteToUser } = require('../controllers/userController');

// @route   GET api/users
// @desc    Obtener todos los usuarios de GHL
// @access  Private
router.get('/', getUsers);

// @route   GET api/users/search
// @desc    Buscar usuarios por término de búsqueda
// @access  Private
router.get('/search', searchUsers);

// @route   GET api/users/:id
// @desc    Obtener un usuario específico de GHL
// @access  Private
router.get('/:id', getUserById);

// @route   POST api/users/:id/notes
// @desc    Agregar una nota a un contacto en GHL
// @access  Private
router.post('/:id/notes', addNoteToUser);

module.exports = router;