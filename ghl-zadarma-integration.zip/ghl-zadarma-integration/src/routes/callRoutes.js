const express = require('express');
const router = express.Router();
const { 
  initiateCall, 
  getCallStatus, 
  logCall, 
  getCallHistory,
  getSipConfiguration 
} = require('../controllers/callController');

// @route   POST api/calls/initiate
// @desc    Iniciar una llamada con Zadarma
// @access  Private
router.post('/initiate', initiateCall);

// @route   GET api/calls/:id/status
// @desc    Obtener estado de una llamada
// @access  Private
router.get('/:id/status', getCallStatus);

// @route   POST api/calls/log
// @desc    Registrar una llamada en el sistema
// @access  Private
router.post('/log', logCall);

// @route   GET api/calls/history
// @desc    Obtener historial de llamadas
// @access  Private
router.get('/history', getCallHistory);

// @route   GET api/calls/sip-config
// @desc    Obtener configuración SIP para WebPhone
// @access  Private
router.get('/sip-config', getSipConfiguration);

module.exports = router;