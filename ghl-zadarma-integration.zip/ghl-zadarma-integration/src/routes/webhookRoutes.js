const express = require('express');
const router = express.Router();
const { zadarmaWebhook } = require('../controllers/webhookController');

// @route   POST /api/webhook/zadarma
// @desc    Recibir notificaciones de Zadarma
// @access  Public
router.post('/zadarma', zadarmaWebhook);

module.exports = router;