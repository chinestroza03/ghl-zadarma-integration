import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Comprobar si hay un token al cargar la aplicación
  useEffect(() => {
    const loadUser = async () => {
      if (token) {
        try {
          // Configurar el token en los headers
          axios.defaults.headers.common['x-auth-token'] = token;
          
          // Obtener información del usuario
          const res = await axios.get('/api/auth/user');
          setUser(res.data);
        } catch (err) {
          // Si hay un error, eliminar el token
          localStorage.removeItem('token');
          setToken(null);
          delete axios.defaults.headers.common['x-auth-token'];
        }
      }
      
      setLoading(false);
    };
    
    loadUser();
  }, [token]);
  
  // Función para iniciar sesión
  const login = async (email, password) => {
    try {
      const res = await axios.post('/api/auth/login', { email, password });
      
      // Guardar el token en localStorage
      localStorage.setItem('token', res.data.token);
      setToken(res.data.token);
      
      // Configurar el token en los headers
      axios.defaults.headers.common['x-auth-token'] = res.data.token;
      
      // Cargar la información del usuario
      const userRes = await axios.get('/api/auth/user');
      setUser(userRes.data);
      
      return { success: true };
    } catch (err) {
      return {
        success: false,
        error: err.response?.data?.msg || 'Error al iniciar sesión'
      };
    }
  };
  
  // Función para cerrar sesión
  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    delete axios.defaults.headers.common['x-auth-token'];
  };
  
  return (
    <AuthContext.Provider
      value={{
        token,
        isAuthenticated: !!token,
        user,
        loading,
        login,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};