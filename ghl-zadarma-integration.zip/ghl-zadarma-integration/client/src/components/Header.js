import React, { useState } from 'react';
import { Menu, Bell, Search, User } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

const Header = ({ toggleSidebar }) => {
  const { user } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="flex items-center justify-between h-16 px-4">
        <div className="flex items-center">
          <button
            onClick={toggleSidebar}
            className="text-gray-500 focus:outline-none lg:hidden"
          >
            <Menu className="w-6 h-6" />
          </button>
          
          <div className="relative mx-4 lg:mx-0">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3">
              <Search className="w-5 h-5 text-gray-400" />
            </span>
            <input
              className="w-32 sm:w-64 rounded-md pl-10 pr-4 py-2 border border-gray-300 focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              type="text"
              placeholder="Buscar..."
            />
          </div>
        </div>
        
        <div className="flex items-center">
          <button className="flex mx-4 text-gray-600 focus:outline-none">
            <Bell className="w-6 h-6" />
          </button>
          
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="relative z-10 block rounded-md bg-white p-2 focus:outline-none"
            >
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white">
                  <User className="w-5 h-5" />
                </div>
                <span className="hidden md:block text-gray-700">
                  {user?.name || 'Usuario'}
                </span>
              </div>
            </button>
            
            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                
                  href="#perfil"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-500 hover:text-white"
                >
                  Mi perfil
                </a>
                
                  href="#configuracion"
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-500 hover:text-white"
                >
                  Configuración
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;