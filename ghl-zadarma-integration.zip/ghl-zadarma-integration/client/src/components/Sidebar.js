import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Users, Phone, Settings, BarChart2, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

const Sidebar = ({ isOpen, setIsOpen }) => {
  const location = useLocation();
  const { logout } = useAuth();
  
  const links = [
    { name: 'Dashboard', to: '/dashboard', icon: BarChart2 },
    { name: 'Clientes', to: '/users', icon: Users },
    { name: 'Llamadas', to: '/calls', icon: Phone },
    { name: 'Configuración', to: '/settings', icon: Settings }
  ];
  
  return (
    <div 
      className={`bg-indigo-800 text-white fixed inset-y-0 left-0 z-30 w-64 transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      <div className="flex items-center justify-center h-16 border-b border-indigo-700">
        <h1 className="text-xl font-bold">GHL Integrator</h1>
      </div>
      
      <nav className="mt-5">
        <div className="px-2">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.to;
            
            return (
              <Link
                key={link.name}
                to={link.to}
                className={`flex items-center px-4 py-3 mt-2 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-indigo-700 text-white' 
                    : 'text-indigo-200 hover:bg-indigo-700 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5 mr-3" />
                <span>{link.name}</span>
              </Link>
            );
          })}
        </div>
        
        <div className="px-2 mt-auto absolute bottom-5 w-full">
          <button
            onClick={logout}
            className="flex items-center w-full px-4 py-3 mt-2 text-indigo-200 rounded-lg hover:bg-indigo-700 hover:text-white transition-colors"
          >
            <LogOut className="w-5 h-5 mr-3" />
            <span>Cerrar sesión</span>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default Sidebar;