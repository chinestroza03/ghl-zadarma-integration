import React, { useState, useEffect, useRef } from 'react';
import { Phone, PhoneOff, Mic, MicOff, VolumeX, Volume2 } from 'lucide-react';
import JsSIP from 'jssip';
import callService from '../services/callService';

const WebPhone = ({ phoneNumber, onClose }) => {
  // Estados para el teléfono SIP
  const [sipStatus, setSipStatus] = useState('disconnected'); // disconnected, connecting, connected, registering, registered
  const [callStatus, setCallStatus] = useState('idle'); // idle, calling, ringing, active, ended
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [duration, setDuration] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  
  // Referencias
  const userAgentRef = useRef(null);
  const sessionRef = useRef(null);
  const remoteAudioRef = useRef(null);
  const timerRef = useRef(null);
  const durationIntervalRef = useRef(null);
  
  // Configuración SIP
  const [sipConfig, setSipConfig] = useState(null);
  
  // Cargar configuración de SIP
  useEffect(() => {
    const loadSipConfig = async () => {
      try {
        const config = await callService.getSipConfig();
        setSipConfig(config);
      } catch (error) {
        console.error('Error al cargar configuración SIP:', error);
        setErrorMessage('No se pudo cargar la configuración SIP');
      }
    };
    
    loadSipConfig();
    
    // Limpiar al desmontar
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
      
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
      
      hangupCall();
      disconnectSIP();
    };
  }, []);
  
  // Inicializar JsSIP cuando la configuración esté disponible
  useEffect(() => {
    if (!sipConfig) return;
    
    try {
      initializeSIP();
    } catch (error) {
      console.error('Error al inicializar SIP:', error);
      setErrorMessage('Error al inicializar la conexión SIP');
    }
  }, [sipConfig]);
  
  // Inicializar JsSIP
  const initializeSIP = () => {
    if (!sipConfig) {
      setErrorMessage('Configuración SIP no disponible');
      return;
    }
    
    const { sipId, sipPassword, sipDomain, webSocketUrl } = sipConfig;
    
    // Configurar socket
    const socket = new JsSIP.WebSocketInterface(webSocketUrl);
    
    // Configurar UA
    const uaConfig = {
      uri: `sip:${sipId}@${sipDomain}`,
      password: sipPassword,
      display_name: sipId,
      sockets: [socket],
      registrar_server: `sip:${sipDomain}`,
      contact_uri: `sip:${sipId}@${sipDomain}`,
      authorization_user: sipId,
      register: true,
      session_timers: false,
      user_agent: 'GHL-Zadarma-Integrator'
    };
    
    // Crear UserAgent
    const userAgent = new JsSIP.UA(uaConfig);
    
    // Manejar eventos
    userAgent.on('connected', () => {
      console.log('SIP Connected');
      setSipStatus('connected');
    });
    
    userAgent.on('disconnected', () => {
      console.log('SIP Disconnected');
      setSipStatus('disconnected');
      setErrorMessage('Conexión SIP desconectada');
    });
    
    userAgent.on('registered', () => {
      console.log('SIP Registered');
      setSipStatus('registered');
    });
    
    userAgent.on('registrationFailed', (ev) => {
      console.error('SIP Registration Failed', ev);
      setSipStatus('disconnected');
      setErrorMessage('Error en el registro SIP');
    });
    
    userAgent.on('newRTCSession', (ev) => {
      const session = ev.session;
      
      // Guardar la sesión
      sessionRef.current = session;
      
      if (session.direction === 'incoming') {
        // Manejar llamada entrante
        setCallStatus('ringing');
        
        session.on('accepted', () => {
          setCallStatus('active');
          startDurationTimer();
        });
        
        session.on('ended', () => {
          setCallStatus('ended');
          stopDurationTimer();
          timerRef.current = setTimeout(() => {
            setCallStatus('idle');
            setDuration(0);
          }, 2000);
        });
        
        session.on('failed', () => {
          setCallStatus('idle');
          stopDurationTimer();
        });
      }
    });
    
    // Iniciar
    userAgent.start();
    
    // Guardar referencia
    userAgentRef.current = userAgent;
    
    // Configurar audio remoto
    JsSIP.debug.enable('JsSIP:*');
  };
  
  // Desconectar SIP
  const disconnectSIP = () => {
    if (userAgentRef.current) {
      try {
        userAgentRef.current.stop();
        userAgentRef.current = null;
      } catch (error) {
        console.error('Error al desconectar SIP:', error);
      }
    }
  };
  
  // Iniciar llamada
  const makeCall = () => {
    if (!userAgentRef.current || sipStatus !== 'registered') {
      setErrorMessage('No está registrado en el servidor SIP');
      return;
    }
    
    if (!phoneNumber) {
      setErrorMessage('Número de teléfono no válido');
      return;
    }
    
    try {
      // Opciones para la llamada
      const options = {
        mediaConstraints: { audio: true, video: false },
        pcConfig: {
          iceServers: [
            { urls: ['stun:stun.l.google.com:19302'] }
          ]
        },
        mediaStream: remoteAudioRef.current.srcObject,
        // Configurar callback para flujo remoto
        eventHandlers: {
          peerconnection: function(e) {
            e.peerconnection.addEventListener('track', function(event) {
              remoteAudioRef.current.srcObject = event.streams[0];
            });
          }
        }
      };
      
      // Normalizar número
      const normalizedNumber = normalizePhoneNumber(phoneNumber);
      
      // Iniciar la llamada
      const session = userAgentRef.current.call(`sip:${normalizedNumber}@${sipConfig.sipDomain}`, options);
      sessionRef.current = session;
      
      // Configurar eventos de la sesión
      session.on('connecting', () => {
        setCallStatus('calling');
      });
      
      session.on('progress', () => {
        setCallStatus('calling');
      });
      
      session.on('accepted', () => {
        setCallStatus('active');
        startDurationTimer();
        
        // Registrar llamada en el sistema
        logCallToSystem(normalizedNumber, 'outgoing');
      });
      
      session.on('ended', () => {
        setCallStatus('ended');
        stopDurationTimer();
        timerRef.current = setTimeout(() => {
          setCallStatus('idle');
          setDuration(0);
        }, 2000);
      });
      
      session.on('failed', (e) => {
        setCallStatus('idle');
        stopDurationTimer();
        setErrorMessage(`Error: ${e.cause}`);
      });
      
    } catch (error) {
      console.error('Error al realizar llamada:', error);
      setErrorMessage('Error al iniciar la llamada');
    }
  };
  
  // Colgar llamada
  const hangupCall = () => {
    if (sessionRef.current) {
      try {
        if (callStatus === 'active' || callStatus === 'calling' || callStatus === 'ringing') {
          sessionRef.current.terminate();
        }
      } catch (error) {
        console.error('Error al colgar:', error);
      }
    }
  };
  
  // Silenciar/activar micrófono
  const toggleMute = () => {
    if (sessionRef.current && callStatus === 'active') {
      try {
        if (isMuted) {
          sessionRef.current.unmute();
        } else {
          sessionRef.current.mute();
        }
        
        setIsMuted(!isMuted);
      } catch (error) {
        console.error('Error al cambiar estado del micrófono:', error);
      }
    }
  };
  
  // Altavoz on/off
  const toggleSpeaker = () => {
    if (remoteAudioRef.current) {
      remoteAudioRef.current.muted = isSpeakerOn;
      setIsSpeakerOn(!isSpeakerOn);
    }
  };
  
  // Iniciar temporizador de duración
  const startDurationTimer = () => {
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
    }
    
    setDuration(0);
    durationIntervalRef.current = setInterval(() => {
      setDuration(prev => prev + 1);
    }, 1000);
  };
  
  // Detener temporizador de duración
  const stopDurationTimer = () => {
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
      durationIntervalRef.current = null;
    }
  };
  
  // Normalizar número de teléfono (eliminar espacios, guiones, etc.)
  const normalizePhoneNumber = (number) => {
    return number.replace(/\s+|-|\(|\)|\.|\+/g, '');
  };
  
  // Formatear duración (mm:ss)
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };
  
  // Registrar llamada en el sistema
  const logCallToSystem = async (phoneNumber, type) => {
    try {
      await callService.logCall({
        phoneNumber,
        type,
        startTime: new Date()
      });
    } catch (error) {
      console.error('Error al registrar llamada:', error);
    }
  };
  
  return (
    <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg p-4 w-80 z-50">
      {/* Audio remoto (oculto) */}
      <audio ref={remoteAudioRef} autoPlay />
      
      {/* Cabecera */}
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold text-lg">WebPhone SIP</h3>
        <div className="flex items-center">
          <div className={`w-2 h-2 rounded-full mr-2 ${
            sipStatus === 'registered' 
              ? 'bg-green-500' 
              : sipStatus === 'connected' || sipStatus === 'connecting' 
                ? 'bg-yellow-500' 
                : 'bg-red-500'
          }`} />
          <span className="text-xs text-gray-500">{sipStatus}</span>
        </div>
        {callStatus === 'idle' && (
          <button onClick={onClose} className="ml-2 text-gray-400 hover:text-gray-600">
            &times;
          </button>
        )}
      </div>
      
      {/* Número e información */}
      <div className="text-center mb-6">
        <div className="text-xl font-medium">{phoneNumber}</div>
        
        {errorMessage && (
          <div className="text-sm text-red-500 mt-1">{errorMessage}</div>
        )}
        
        {callStatus === 'idle' && (
          <div className="text-sm text-gray-500 mt-1">
            {sipStatus === 'registered' 
              ? 'Listo para llamar' 
              : 'Conectando al servicio...'}
          </div>
        )}
        
        {callStatus === 'calling' && (
          <div className="text-sm text-blue-500 mt-1 animate-pulse">
            Llamando...
          </div>
        )}
        
        {callStatus === 'ringing' && (
          <div className="text-sm text-blue-500 mt-1 animate-pulse">
            Llamada entrante...
          </div>
        )}
        
        {callStatus === 'active' && (
          <div className="text-sm text-green-500 mt-1">
            En llamada - {formatDuration(duration)}
          </div>
        )}
        
        {callStatus === 'ended' && (
          <div className="text-sm text-red-500 mt-1">
            Llamada finalizada - {formatDuration(duration)}
          </div>
        )}
      </div>
      
      {/* Controles */}
      <div className="flex justify-center items-center space-x-4">
        {/* Botón de llamada/colgar */}
        {(callStatus === 'idle' || callStatus === 'ended') && (
          <button
            onClick={makeCall}
            disabled={sipStatus !== 'registered'}
            className={`p-4 rounded-full ${
              sipStatus === 'registered'
                ? 'bg-green-500 hover:bg-green-600 text-white'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            <Phone size={24} />
          </button>
        )}
        
        {(callStatus === 'active' || callStatus === 'calling' || callStatus === 'ringing') && (
          <button
            onClick={hangupCall}
            className="p-4 rounded-full bg-red-500 hover:bg-red-600 text-white"
          >
            <PhoneOff size={24} />
          </button>
        )}
        
        {/* Botones adicionales solo para llamadas activas */}
        {callStatus === 'active' && (
          <>
            {/* Botón de silenciar */}
            <button
              onClick={toggleMute}
              className={`p-3 rounded-full ${
                isMuted
                  ? 'bg-red-100 text-red-500'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
            </button>
            
            {/* Botón de altavoz */}
            <button
              onClick={toggleSpeaker}
              className={`p-3 rounded-full ${
                !isSpeakerOn
                  ? 'bg-red-100 text-red-500'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {!isSpeakerOn ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </button>
          </>
        )}
      </div>
      
      {/* Mensajes de estado SIP */}
      <div className="mt-4 text-xs text-gray-500 text-center">
        {sipStatus !== 'registered' && sipStatus !== 'disconnected' && (
          <div className="animate-pulse">Conectando a servidor SIP...</div>
        )}
      </div>
    </div>
  );
};

export default WebPhone;