import axios from 'axios';

// Crear instancia de axios con configuración base
const callApi = axios.create({
  baseURL: '/api/calls',
  headers: {
    'Content-Type': 'application/json',
  }
});

// Interceptor para agregar el token a las solicitudes
callApi.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['x-auth-token'] = token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const callService = {
  // Iniciar una llamada
  initiateCall: async (phoneNumber, callerId = null) => {
    try {
      const response = await callApi.post('/initiate', { 
        phoneNumber, 
        callerId 
      });
      return response.data;
    } catch (error) {
      console.error('Error al iniciar llamada:', error);
      throw error;
    }
  },
  
  // Obtener estado de una llamada
  getCallStatus: async (callId) => {
    try {
      const response = await callApi.get(`/${callId}/status`);
      return response.data;
    } catch (error) {
      console.error(`Error al obtener estado de llamada ${callId}:`, error);
      throw error;
    }
  },
  
  // Obtener historial de llamadas
  getCallHistory: async (filters = {}) => {
    try {
      const { limit, page, userId, startDate, endDate, type } = filters;
      let url = '/history?';
      
      if (limit) url += `limit=${limit}&`;
      if (page) url += `page=${page}&`;
      if (userId) url += `userId=${userId}&`;
      if (startDate) url += `startDate=${startDate}&`;
      if (endDate) url += `endDate=${endDate}&`;
      if (type) url += `type=${type}&`;
      
      const response = await callApi.get(url);
      return response.data;
    } catch (error) {
      console.error('Error al obtener historial de llamadas:', error);
      throw error;
    }
  },
  
  // Registrar una llamada en el sistema
  logCall: async (callData) => {
    try {
      const response = await callApi.post('/log', callData);
      return response.data;
    } catch (error) {
      console.error('Error al registrar la llamada:', error);
      throw error;
    }
  },
  
  // Finalizar una llamada activa
  endCall: async (callId) => {
    try {
      const response = await callApi.post(`/${callId}/end`);
      return response.data;
    } catch (error) {
      console.error(`Error al finalizar la llamada ${callId}:`, error);
      throw error;
    }
  },
  
  // Obtener configuración SIP
  getSipConfig: async () => {
    try {
      const response = await callApi.get('/sip-config');
      return response.data.data;
    } catch (error) {
      console.error('Error al obtener configuración SIP:', error);
      throw error;
    }
  }
};

export default callService;