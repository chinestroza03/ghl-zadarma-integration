import axios from 'axios';

// Crear instancia de axios con configuración base
const ghlApi = axios.create({
  baseURL: '/api/users',
  headers: {
    'Content-Type': 'application/json',
  }
});

// Interceptor para agregar el token a las solicitudes
ghlApi.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['x-auth-token'] = token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const ghlService = {
  // Obtener todos los usuarios/contactos con filtros opcionales
  getUsers: async (filters = {}) => {
    try {
      const { limit, page, query, status } = filters;
      let url = '?';
      
      if (limit) url += `limit=${limit}&`;
      if (page) url += `page=${page}&`;
      if (query) url += `query=${query}&`;
      if (status) url += `status=${status}&`;
      
      const response = await ghlApi.get(url);
      return response.data;
    } catch (error) {
      console.error('Error al obtener usuarios:', error);
      throw error;
    }
  },
  
  // Obtener un usuario/contacto específico
  getUserById: async (id) => {
    try {
      const response = await ghlApi.get(`/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error al obtener usuario ${id}:`, error);
      throw error;
    }
  },
  
  // Buscar usuarios por término de búsqueda
  searchUsers: async (searchTerm) => {
    try {
      const response = await ghlApi.get(`/search?query=${searchTerm}`);
      return response.data;
    } catch (error) {
      console.error('Error al buscar usuarios:', error);
      throw error;
    }
  },
  
  // Agregar una nota a un usuario
  addNoteToUser: async (userId, body) => {
    try {
      const response = await ghlApi.post(`/${userId}/notes`, { body });
      return response.data;
    } catch (error) {
      console.error(`Error al agregar nota al usuario ${userId}:`, error);
      throw error;
    }
  }
};

export default ghlService;