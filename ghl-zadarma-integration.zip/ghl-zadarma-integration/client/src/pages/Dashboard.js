import React, { useState, useEffect } from 'react';
import { Search, Phone, Filter, User } from 'lucide-react';
import ghlService from '../services/ghlService';
import WebPhone from '../components/WebPhone';

const Dashboard = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilters, setActiveFilters] = useState({
    status: 'all',
    lastContact: 'all'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showWebPhone, setShowWebPhone] = useState(false);
  const [callToNumber, setCallToNumber] = useState('');

  // Obtener usuarios de GHL
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        
        // Parámetros de filtro
        const filters = {
          limit: 20,
          page: currentPage,
          query: searchTerm,
          status: activeFilters.status !== 'all' ? activeFilters.status : undefined
        };
        
        // Llamar al servicio GHL
        const response = await ghlService.getUsers(filters);
        
        if (response && response.contacts) {
          setUsers(response.contacts);
          setFilteredUsers(response.contacts);
          
          // Calcular páginas totales
          if (response.meta && response.meta.total) {
            const totalRecords = response.meta.total;
            const limit = filters.limit;
            setTotalPages(Math.ceil(totalRecords / limit));
          }
        }
      } catch (error) {
        console.error('Error al obtener usuarios:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, [currentPage, searchTerm, activeFilters]);

  // Filtrar usuarios (si es necesario realizar filtrado adicional en cliente)
  useEffect(() => {
    if (activeFilters.lastContact !== 'all') {
      let result = [...users];
      
      const today = new Date();
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(today.getDate() - 30);
      
      if (activeFilters.lastContact === 'recent') {
        result = result.filter(user => {
          if (!user.lastActivity) return false;
          const contactDate = new Date(user.lastActivity);
          return contactDate >= thirtyDaysAgo;
        });
      } else if (activeFilters.lastContact === 'old') {
        result = result.filter(user => {
          if (!user.lastActivity) return true;
          const contactDate = new Date(user.lastActivity);
          return contactDate < thirtyDaysAgo;
        });
      }
      
      setFilteredUsers(result);
    } else {
      setFilteredUsers(users);
    }
  }, [activeFilters.lastContact, users]);

  // Manejar búsqueda con debounce
  useEffect(() => {
    const handler = setTimeout(() => {
      // La búsqueda se realiza en el primer useEffect cuando cambia searchTerm
      setCurrentPage(1); // Resetear a primera página cuando se busca
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [searchTerm]);

  // Manejar cambio de página
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  // Iniciar llamada WebPhone
  const handleCall = (phoneNumber) => {
    setCallToNumber(phoneNumber);
    setShowWebPhone(true);
  };

  // Cerrar WebPhone
  const handleCloseWebPhone = () => {
    setShowWebPhone(false);
    setCallToNumber('');
  };

  if (isLoading && users.length === 0) {
    return <div className="p-8 text-center">Cargando usuarios...</div>;
  }

  return (
    <div className="p-4 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Dashboard de Clientes</h1>
        
        {/* Barra superior con búsqueda y filtros */}
        <div className="bg-white p-4 rounded-lg shadow mb-6 flex flex-wrap gap-4 items-center justify-between">
          <div className="relative flex-grow max-w-md">
            <input
              type="text"
              placeholder="Buscar clientes..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          </div>
          
          <div className="flex gap-4">
            <select 
              className="border rounded-lg px-3 py-2"
              value={activeFilters.status}
              onChange={(e) => setActiveFilters({...activeFilters, status: e.target.value})}
            >
              <option value="all">Todos los estados</option>
              <option value="active">Activos</option>
              <option value="inactive">Inactivos</option>
              <option value="pending">Pendientes</option>
            </select>
            
            <select 
              className="border rounded-lg px-3 py-2"
              value={activeFilters.lastContact}
              onChange={(e) => setActiveFilters({...activeFilters, lastContact: e.target.value})}
            >
              <option value="all">Cualquier contacto</option>
              <option value="recent">Contactados recientemente</option>
              <option value="old">Sin contacto reciente</option>
            </select>
          </div>
        </div>
        
        {/* Listado de usuarios */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contacto</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Último Contacto</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-10 h-10 flex-shrink-0 bg-gray-200 rounded-full flex items-center justify-center">
                          <User className="text-gray-500" size={18} />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{user.name || 'Sin nombre'}</div>
                          {user.company && (
                            <div className="text-sm text-gray-500">{user.company}</div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{user.phone || 'Sin teléfono'}</div>
                      <div className="text-sm text-gray-500">{user.email || 'Sin email'}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${user.status === 'active' ? 'bg-green-100 text-green-800' : 
                          user.status === 'inactive' ? 'bg-red-100 text-red-800' : 
                          'bg-yellow-100 text-yellow-800'}`}>
                        {user.status === 'active' ? 'Activo' : 
                          user.status === 'inactive' ? 'Inactivo' : 'Pendiente'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {user.lastActivity 
                        ? new Date(user.lastActivity).toLocaleDateString('es-ES') 
                        : 'Sin actividad'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      {user.phone && (
                        <button 
                          onClick={() => handleCall(user.phone)}
                          className="text-indigo-600 hover:text-indigo-900 inline-flex items-center"
                        >
                          <Phone size={16} className="mr-1" />
                          Llamar
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="px-6 py-4 text-center text-sm text-gray-500">
                    No se encontraron clientes con los filtros actuales
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Paginación */}
        {totalPages > 1 && (
          <div className="flex justify-center mt-4">
            <nav className="flex items-center">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className={`px-3 py-1 rounded-l-md border ${
                  currentPage === 1
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-white text-indigo-600 hover:bg-indigo-50'
                }`}
              >
                Anterior
              </button>
              
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                // Cálculo para mostrar las páginas centradas alrededor de la página actual
                let pageNum;
                if (totalPages <= 5) {
                  pageNum = i + 1;
                } else if (currentPage <= 3) {
                  pageNum = i + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                } else {
                  pageNum = currentPage - 2 + i;
                }
                
                return (
                  <button
                    key={pageNum}
                    onClick={() => handlePageChange(pageNum)}
                    className={`px-3 py-1 border-t border-b ${
                      currentPage === pageNum
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white text-indigo-600 hover:bg-indigo-50'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}
              
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={`px-3 py-1 rounded-r-md border ${
                  currentPage === totalPages
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-white text-indigo-600 hover:bg-indigo-50'
                }`}
              >
                Siguiente
              </button>
            </nav>
          </div>
        )}
      </div>
      
      {/* Componente WebPhone */}
      {showWebPhone && (
        <WebPhone 
          phoneNumber={callToNumber} 
          onClose={handleCloseWebPhone} 
        />
      )}
    </div>
  );
};

export default Dashboard;